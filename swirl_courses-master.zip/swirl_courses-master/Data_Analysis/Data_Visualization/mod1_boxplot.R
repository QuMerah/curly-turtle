# Box plot
boxplot(price ~ type, data=cars, xlab="Type", ylab="Price")